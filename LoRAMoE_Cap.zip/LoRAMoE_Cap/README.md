# LoRaMoE-Cap

Reference PyTorch implementation of **LoRaMoE-Cap**, a diagram captioning framework that combines:

- a ViT image encoder
- a vision-language projector
- a DistilBERT text encoder
- a sparse Mixture-of-Experts layer with **Top-2 routing**
- **LoRA** inside each expert
- a lightweight Transformer decoder ("TinyLM")

This repository is a clean, GitHub-ready implementation reconstructed from the architecture and training procedure described in the attached manuscript. The paper states that the model concatenates projected visual embeddings with DistilBERT text embeddings, routes them through **3 experts**, applies **LoRA** inside each expert, and trains with caption cross-entropy plus **KL regularization** toward a uniform expert prior. It also reports **Top-2 routing**, **LoRA rank 8**, **batch size 16**, **AdamW**, **learning rate 5e-5**, and **10 fine-tuning epochs**. fileciteturn1file1 fileciteturn1file9 fileciteturn1file7

## Important note

This is a **faithful engineering implementation based on the paper**, not the authors' original private source code. The manuscript gives the architecture and training procedure, but not every low-level implementation detail. Where the paper is silent, practical defaults are used and clearly isolated in config files.

## Repository layout

```text
loramoe_cap_repo/
├── .github/workflows/ci.yml
├── configs/default.yaml
├── pyproject.toml
├── requirements.txt
├── scripts/
│   ├── train.py
│   ├── evaluate.py
│   └── infer.py
├── src/loramoe_cap/
│   ├── __init__.py
│   ├── config.py
│   ├── trainer.py
│   ├── metrics.py
│   ├── data/
│   │   ├── dataset.py
│   │   └── collator.py
│   ├── models/
│   │   ├── lora.py
│   │   ├── projector.py
│   │   ├── text_encoder.py
│   │   ├── tiny_decoder.py
│   │   ├── moe.py
│   │   └── loramoe_cap.py
│   └── utils/
│       ├── checkpointing.py
│       ├── seed.py
│       └── logging_utils.py
└── tests/
    └── test_forward.py
```

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Dataset format

Expected JSONL rows:

```json
{"image": "path/to/img.png", "instruction": "Describe this scientific diagram.", "caption": "The diagram shows ...", "split": "train"}
```

## Train

```bash
python scripts/train.py --config configs/default.yaml
```

## Evaluate

```bash
python scripts/evaluate.py --config configs/default.yaml --checkpoint outputs/best.pt
```

## Inference

```bash
python scripts/infer.py \
  --config configs/default.yaml \
  --checkpoint outputs/best.pt \
  --image path/to/example.png \
  --instruction "Describe this diagram."
```

## What is implemented from the paper

The attached manuscript specifies:

- projected ViT patch embeddings + DistilBERT text embeddings are concatenated into a multimodal representation `F` fileciteturn1file1
- the MoE layer uses **K = 3** experts and sparse **Top-2** routing fileciteturn1file9
- gating probabilities are softmax scores over expert weights `w_k` fileciteturn1file9
- each expert uses a LoRA update `ΔW_k = A_k B_k^T` with frozen base weights and learned low-rank adapters fileciteturn1file9
- training uses caption cross-entropy plus KL regularization against a uniform prior over experts fileciteturn1file6
- the paper's reported fine-tuning hyperparameters include AdamW, learning rate `5e-5`, batch size `16`, LoRA rank `8`, dropout `0.1`, and `10` epochs fileciteturn1file7

## Engineering assumptions added here

The paper does not fully define:

- the exact decoder block implementation
- the exact hidden sizes of all internal projections
- tokenizer special-token handling
- the exact image preprocessing pipeline
- the exact checkpoint naming and logging format

So this repo uses standard Hugging Face / PyTorch implementations for those parts.

## License

MIT
