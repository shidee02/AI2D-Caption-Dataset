from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torchvision import transforms
from transformers import AutoTokenizer


@dataclass
class DiagramCollator:
    tokenizer_name: str
    image_size: int
    max_target_length: int

    def __post_init__(self) -> None:
        self.tokenizer = AutoTokenizer.from_pretrained(self.tokenizer_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token or self.tokenizer.sep_token
        self.image_tf = transforms.Compose(
            [
                transforms.Resize((self.image_size, self.image_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
            ]
        )

    def __call__(self, batch: list[dict[str, Any]]) -> dict[str, torch.Tensor | list[str]]:
        images = torch.stack([self.image_tf(x["image"]) for x in batch])
        instructions = [x["instruction"] for x in batch]
        captions = [x["caption"] for x in batch]

        text_inputs = self.tokenizer(
            instructions,
            padding=True,
            truncation=True,
            return_tensors="pt",
        )
        targets = self.tokenizer(
            captions,
            padding=True,
            truncation=True,
            max_length=self.max_target_length,
            return_tensors="pt",
        )
        labels = targets["input_ids"].clone()
        labels[labels == self.tokenizer.pad_token_id] = -100

        return {
            "pixel_values": images,
            "instruction_input_ids": text_inputs["input_ids"],
            "instruction_attention_mask": text_inputs["attention_mask"],
            "labels": labels,
            "target_input_ids": targets["input_ids"],
            "target_attention_mask": targets["attention_mask"],
            "raw_captions": captions,
        }
