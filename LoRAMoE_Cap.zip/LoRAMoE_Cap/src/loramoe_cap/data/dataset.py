from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from PIL import Image
from torch.utils.data import Dataset


class DiagramCaptionDataset(Dataset):
    def __init__(self, jsonl_path: str | Path):
        self.samples: list[dict[str, Any]] = []
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    self.samples.append(json.loads(line))

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        row = self.samples[idx]
        image = Image.open(row["image"]).convert("RGB")
        return {
            "image": image,
            "instruction": row.get("instruction", "Describe this scientific diagram."),
            "caption": row["caption"],
        }
