from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch.cuda.amp import GradScaler, autocast
from torch.optim import AdamW
from torch.utils.data import DataLoader
from tqdm import tqdm

from .metrics import compute_caption_metrics
from .utils.checkpointing import save_checkpoint
from .utils.logging_utils import get_logger


class Trainer:
    def __init__(self, model, cfg: dict[str, Any]):
        self.model = model
        self.cfg = cfg
        self.logger = get_logger()
        self.output_dir = Path(cfg["output_dir"])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.device = torch.device(cfg["train"]["device"] if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=float(cfg["train"]["lr"]),
            weight_decay=float(cfg["train"]["weight_decay"]),
        )
        self.scaler = GradScaler(enabled=bool(cfg["train"].get("mixed_precision", True)))
        self.best_metric = float("-inf")

    def _move(self, batch: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in batch.items():
            out[k] = v.to(self.device) if torch.is_tensor(v) else v
        return out

    def train(self, train_loader: DataLoader, val_loader: DataLoader) -> None:
        epochs = int(self.cfg["train"]["epochs"])
        for epoch in range(1, epochs + 1):
            self.model.train()
            pbar = tqdm(train_loader, desc=f"train epoch {epoch}")
            for batch in pbar:
                batch = self._move(batch)
                self.optimizer.zero_grad(set_to_none=True)
                with autocast(enabled=bool(self.cfg["train"].get("mixed_precision", True))):
                    out = self.model(
                        pixel_values=batch["pixel_values"],
                        instruction_input_ids=batch["instruction_input_ids"],
                        instruction_attention_mask=batch["instruction_attention_mask"],
                        target_input_ids=batch["target_input_ids"],
                        labels=batch["labels"],
                    )
                self.scaler.scale(out.loss).backward()
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), float(self.cfg["train"]["grad_clip_norm"]))
                self.scaler.step(self.optimizer)
                self.scaler.update()
                pbar.set_postfix(loss=float(out.loss.detach().cpu()))

            metrics = self.evaluate(val_loader)
            self.logger.info("epoch=%s metrics=%s", epoch, metrics)
            main_metric = float(metrics[self.cfg["train"]["save_best_metric"]])
            if main_metric > self.best_metric:
                self.best_metric = main_metric
                save_checkpoint(
                    self.output_dir / "best.pt",
                    {
                        "model_state_dict": self.model.state_dict(),
                        "optimizer_state_dict": self.optimizer.state_dict(),
                        "epoch": epoch,
                        "metrics": metrics,
                        "config": self.cfg,
                    },
                )

    @torch.no_grad()
    def evaluate(self, data_loader: DataLoader) -> dict[str, float]:
        self.model.eval()
        preds, refs = [], []
        for batch in tqdm(data_loader, desc="eval"):
            batch = self._move(batch)
            generated = self.model.generate(
                pixel_values=batch["pixel_values"],
                instruction_input_ids=batch["instruction_input_ids"],
                instruction_attention_mask=batch["instruction_attention_mask"],
                max_new_tokens=int(self.cfg["inference"]["max_new_tokens"]),
            )
            preds.extend(generated)
            refs.extend(batch["raw_captions"])
        return compute_caption_metrics(preds, refs)
