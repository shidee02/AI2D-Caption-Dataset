from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import timm
import torch
from torch import nn
from transformers import AutoTokenizer

from .moe import SparseMoE
from .projector import VisionLanguageProjector
from .text_encoder import DistilBERTTextEncoder
from .tiny_decoder import TinyLMDecoder


@dataclass
class ForwardOutput:
    loss: Optional[torch.Tensor]
    logits: torch.Tensor
    gate_probs: torch.Tensor
    topk_indices: torch.Tensor
    ce_loss: Optional[torch.Tensor]
    kl_loss: Optional[torch.Tensor]


class LoRaMoECap(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        mcfg = cfg["model"]
        tcfg = cfg["train"]

        self.tokenizer = AutoTokenizer.from_pretrained(mcfg["decoder_vocab_source"])
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token or self.tokenizer.sep_token

        self.image_encoder = timm.create_model(mcfg["image_encoder_name"], pretrained=True, num_classes=0)
        img_dim = self.image_encoder.num_features
        self.text_encoder = DistilBERTTextEncoder(mcfg["text_encoder_name"])
        self.projector = VisionLanguageProjector(img_dim, mcfg["projector_dim"], mcfg["dropout"])
        self.moe = SparseMoE(
            dim=mcfg["projector_dim"],
            hidden_dim=mcfg["expert_hidden_dim"],
            num_experts=mcfg["num_experts"],
            top_k=mcfg["top_k"],
            rank=mcfg["lora_rank"],
            alpha=mcfg["lora_alpha"],
            dropout=mcfg["dropout"],
        )
        self.decoder = TinyLMDecoder(
            vocab_size=len(self.tokenizer),
            d_model=mcfg["projector_dim"],
            nhead=mcfg["decoder_heads"],
            num_layers=mcfg["decoder_layers"],
            ff_dim=mcfg["decoder_ffn_dim"],
            dropout=mcfg["dropout"],
            pad_token_id=self.tokenizer.pad_token_id,
            max_len=mcfg["max_decode_len"],
        )
        self.kl_lambda = float(tcfg["kl_lambda"])

    def encode_image(self, pixel_values: torch.Tensor) -> torch.Tensor:
        feats = self.image_encoder.forward_features(pixel_values)
        if feats.ndim == 4:
            feats = feats.flatten(2).transpose(1, 2)
        return self.projector(feats)

    def encode_text(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        return self.text_encoder(input_ids, attention_mask)

    def build_memory(self, pixel_values: torch.Tensor, instruction_input_ids: torch.Tensor, instruction_attention_mask: torch.Tensor):
        v = self.encode_image(pixel_values)
        t = self.encode_text(instruction_input_ids, instruction_attention_mask)
        if v.size(-1) != t.size(-1):
            raise ValueError("Projected visual dim and text encoder dim must match.")
        f = torch.cat([v, t], dim=1)
        moe_out = self.moe(f)
        return moe_out

    def forward(
        self,
        pixel_values: torch.Tensor,
        instruction_input_ids: torch.Tensor,
        instruction_attention_mask: torch.Tensor,
        target_input_ids: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ) -> ForwardOutput:
        moe_out = self.build_memory(pixel_values, instruction_input_ids, instruction_attention_mask)
        decoder_in = target_input_ids[:, :-1]
        logits = self.decoder(decoder_in, moe_out.fused)

        loss = ce_loss = kl_loss = None
        if labels is not None:
            shifted_labels = labels[:, 1:]
            ce_loss = nn.functional.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                shifted_labels.reshape(-1),
                ignore_index=-100,
            )
            uniform = torch.full_like(moe_out.gate_probs, 1.0 / moe_out.gate_probs.size(-1))
            kl_loss = torch.nn.functional.kl_div(
                torch.log(moe_out.gate_probs + 1e-8),
                uniform,
                reduction="batchmean",
            )
            loss = ce_loss + self.kl_lambda * kl_loss

        return ForwardOutput(
            loss=loss,
            logits=logits,
            gate_probs=moe_out.gate_probs,
            topk_indices=moe_out.topk_indices,
            ce_loss=ce_loss,
            kl_loss=kl_loss,
        )

    @torch.no_grad()
    def generate(
        self,
        pixel_values: torch.Tensor,
        instruction_input_ids: torch.Tensor,
        instruction_attention_mask: torch.Tensor,
        max_new_tokens: int = 64,
    ) -> list[str]:
        self.eval()
        moe_out = self.build_memory(pixel_values, instruction_input_ids, instruction_attention_mask)
        bsz = pixel_values.size(0)
        cur = torch.full(
            (bsz, 1),
            fill_value=self.tokenizer.cls_token_id or self.tokenizer.bos_token_id or self.tokenizer.pad_token_id,
            device=pixel_values.device,
            dtype=torch.long,
        )

        for _ in range(max_new_tokens):
            logits = self.decoder(cur, moe_out.fused)
            next_token = logits[:, -1].argmax(dim=-1, keepdim=True)
            cur = torch.cat([cur, next_token], dim=1)

        return self.tokenizer.batch_decode(cur[:, 1:], skip_special_tokens=True)
