from __future__ import annotations

from dataclasses import dataclass
import torch
from torch import nn

from .lora import LoRALinear


class ExpertMLP(nn.Module):
    def __init__(self, dim: int, hidden_dim: int, rank: int, alpha: int, dropout: float):
        super().__init__()
        self.fc1 = LoRALinear(dim, hidden_dim, rank=rank, alpha=alpha)
        self.act = nn.GELU()
        self.drop = nn.Dropout(dropout)
        self.fc2 = LoRALinear(hidden_dim, dim, rank=rank, alpha=alpha)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.drop(self.act(self.fc1(x))))


@dataclass
class MoEOutput:
    fused: torch.Tensor
    gate_probs: torch.Tensor
    topk_indices: torch.Tensor


class SparseMoE(nn.Module):
    def __init__(self, dim: int, hidden_dim: int, num_experts: int, top_k: int, rank: int, alpha: int, dropout: float):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k
        self.gate = nn.Linear(dim, num_experts)
        self.experts = nn.ModuleList(
            [ExpertMLP(dim, hidden_dim, rank, alpha, dropout) for _ in range(num_experts)]
        )

    def forward(self, x: torch.Tensor) -> MoEOutput:
        # x: [B, L, D]
        pooled = x.mean(dim=1)
        gate_logits = self.gate(pooled)
        gate_probs = torch.softmax(gate_logits, dim=-1)
        topk_probs, topk_indices = torch.topk(gate_probs, k=self.top_k, dim=-1)

        expert_outputs = []
        for expert in self.experts:
            expert_outputs.append(expert(x))
        stacked = torch.stack(expert_outputs, dim=1)  # [B, E, L, D]

        batch_size, _, seq_len, dim = stacked.shape
        selected = []
        for b in range(batch_size):
            idx = topk_indices[b]
            sel = stacked[b, idx]  # [top_k, L, D]
            weight = topk_probs[b].view(self.top_k, 1, 1)
            selected.append((sel * weight).sum(dim=0))
        fused = torch.stack(selected, dim=0)
        return MoEOutput(fused=fused, gate_probs=gate_probs, topk_indices=topk_indices)
