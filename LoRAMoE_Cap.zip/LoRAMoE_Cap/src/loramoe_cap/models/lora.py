from __future__ import annotations

import math
import torch
from torch import nn


class LoRALinear(nn.Module):
    """Frozen linear layer with trainable low-rank update."""

    def __init__(self, in_features: int, out_features: int, rank: int = 8, alpha: int = 16, bias: bool = True):
        super().__init__()
        self.base = nn.Linear(in_features, out_features, bias=bias)
        self.base.weight.requires_grad = False
        if self.base.bias is not None:
            self.base.bias.requires_grad = False

        self.rank = rank
        self.scale = alpha / rank
        self.A = nn.Parameter(torch.zeros(out_features, rank))
        self.B = nn.Parameter(torch.zeros(rank, in_features))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.kaiming_uniform_(self.A, a=math.sqrt(5))
        nn.init.zeros_(self.B)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base(x)
        delta_w = (self.A @ self.B) * self.scale
        return base_out + torch.nn.functional.linear(x, delta_w)
