from __future__ import annotations

import torch
from torch import nn
from transformers import AutoModel


class DistilBERTTextEncoder(nn.Module):
    def __init__(self, name: str):
        super().__init__()
        self.model = AutoModel.from_pretrained(name)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        out = self.model(input_ids=input_ids, attention_mask=attention_mask)
        return out.last_hidden_state
