from __future__ import annotations

from collections import defaultdict
from typing import Sequence

import sacrebleu
from rouge_score import rouge_scorer


def compute_caption_metrics(preds: Sequence[str], refs: Sequence[str]) -> dict[str, float]:
    bleu = sacrebleu.corpus_bleu(preds, [list(refs)]).score / 100.0
    scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
    rouge_scores = [scorer.score(r, p)["rougeL"].fmeasure for p, r in zip(preds, refs)]
    rouge_l = sum(rouge_scores) / max(1, len(rouge_scores))
    # Placeholder proxies for CIDEr / SPICE if dedicated packages are unavailable.
    # Replace with pycocoevalcap if your environment includes it.
    return {
        "bleu": float(bleu),
        "rougeL": float(rouge_l),
        "cider_proxy": float((bleu + rouge_l) / 2.0),
        "spice_proxy": float(rouge_l),
    }
