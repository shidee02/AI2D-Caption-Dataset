from __future__ import annotations

import argparse
from pathlib import Path

import torch
from PIL import Image

from loramoe_cap.config import Config
from loramoe_cap.data.collator import DiagramCollator
from loramoe_cap.models.loramoe_cap import LoRaMoECap
from loramoe_cap.utils.checkpointing import load_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--instruction", default="Describe this scientific diagram.")
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config).raw
    collator = DiagramCollator(
        tokenizer_name=cfg["model"]["decoder_vocab_source"],
        image_size=int(cfg["data"]["image_size"]),
        max_target_length=int(cfg["data"]["max_target_length"]),
    )

    sample = {
        "image": Image.open(Path(args.image)).convert("RGB"),
        "instruction": args.instruction,
        "caption": "",
    }
    batch = collator([sample])
    model = LoRaMoECap(cfg)
    ckpt = load_checkpoint(args.checkpoint)
    model.load_state_dict(ckpt["model_state_dict"])
    device = torch.device(cfg["train"]["device"] if torch.cuda.is_available() else "cpu")
    model.to(device)

    preds = model.generate(
        pixel_values=batch["pixel_values"].to(device),
        instruction_input_ids=batch["instruction_input_ids"].to(device),
        instruction_attention_mask=batch["instruction_attention_mask"].to(device),
        max_new_tokens=int(cfg["inference"]["max_new_tokens"]),
    )
    print(preds[0])


if __name__ == "__main__":
    main()
