from __future__ import annotations

import argparse
from torch.utils.data import DataLoader

from loramoe_cap.config import Config
from loramoe_cap.data.collator import DiagramCollator
from loramoe_cap.data.dataset import DiagramCaptionDataset
from loramoe_cap.models.loramoe_cap import LoRaMoECap
from loramoe_cap.trainer import Trainer
from loramoe_cap.utils.checkpointing import load_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config).raw
    collator = DiagramCollator(
        tokenizer_name=cfg["model"]["decoder_vocab_source"],
        image_size=int(cfg["data"]["image_size"]),
        max_target_length=int(cfg["data"]["max_target_length"]),
    )
    test_ds = DiagramCaptionDataset(cfg["data"]["test_jsonl"])
    test_loader = DataLoader(test_ds, batch_size=int(cfg["train"]["batch_size"]), shuffle=False, num_workers=int(cfg["data"]["num_workers"]), collate_fn=collator)

    model = LoRaMoECap(cfg)
    ckpt = load_checkpoint(args.checkpoint)
    model.load_state_dict(ckpt["model_state_dict"])
    trainer = Trainer(model, cfg)
    print(trainer.evaluate(test_loader))


if __name__ == "__main__":
    main()
