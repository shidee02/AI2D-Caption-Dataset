from __future__ import annotations

import argparse
from torch.utils.data import DataLoader

from loramoe_cap.config import Config
from loramoe_cap.data.collator import DiagramCollator
from loramoe_cap.data.dataset import DiagramCaptionDataset
from loramoe_cap.models.loramoe_cap import LoRaMoECap
from loramoe_cap.trainer import Trainer
from loramoe_cap.utils.seed import set_seed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    cfg = Config.from_yaml(args.config).raw
    set_seed(int(cfg["seed"]))

    collator = DiagramCollator(
        tokenizer_name=cfg["model"]["decoder_vocab_source"],
        image_size=int(cfg["data"]["image_size"]),
        max_target_length=int(cfg["data"]["max_target_length"]),
    )
    train_ds = DiagramCaptionDataset(cfg["data"]["train_jsonl"])
    val_ds = DiagramCaptionDataset(cfg["data"]["val_jsonl"])
    train_loader = DataLoader(train_ds, batch_size=int(cfg["train"]["batch_size"]), shuffle=True, num_workers=int(cfg["data"]["num_workers"]), collate_fn=collator)
    val_loader = DataLoader(val_ds, batch_size=int(cfg["train"]["batch_size"]), shuffle=False, num_workers=int(cfg["data"]["num_workers"]), collate_fn=collator)

    model = LoRaMoECap(cfg)
    trainer = Trainer(model, cfg)
    trainer.train(train_loader, val_loader)


if __name__ == "__main__":
    main()
