from __future__ import annotations

import torch

from loramoe_cap.models.moe import SparseMoE


def test_sparse_moe_shapes() -> None:
    moe = SparseMoE(dim=64, hidden_dim=64, num_experts=3, top_k=2, rank=4, alpha=8, dropout=0.1)
    x = torch.randn(2, 10, 64)
    out = moe(x)
    assert out.fused.shape == (2, 10, 64)
    assert out.gate_probs.shape == (2, 3)
    assert out.topk_indices.shape == (2, 2)
